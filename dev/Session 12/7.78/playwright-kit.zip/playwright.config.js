// FinanceFlow – Playwright konfigurace (S12.1)
// Spuštění:  npx playwright test          (všechny testy, headless)
//            npx playwright test --ui     (interaktivní UI mód)
//            npx playwright test --project=mobile
const { defineConfig, devices } = require('@playwright/test');

module.exports = defineConfig({
  testDir: './tests',
  timeout: 30000,
  retries: 1,
  reporter: [['list'], ['html', { open: 'never' }]],
  use: {
    baseURL: process.env.FF_URL || 'https://financeflow.cz',
    screenshot: 'only-on-failure',
    trace: 'retain-on-failure',
  },
  projects: [
    { name: 'desktop', use: { ...devices['Desktop Chrome'] } },
    { name: 'mobile',  use: { ...devices['Pixel 7'] } },  // mobile-first!
  ],
});
