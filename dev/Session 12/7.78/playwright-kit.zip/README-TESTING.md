# FinanceFlow – Playwright testy (S12.1)

## Instalace (jednorázově, na PC)
```bash
mkdir ff-tests && cd ff-tests
# rozbal sem obsah playwright-kit.zip
npm install
npx playwright install chromium
```

## Spuštění
```bash
npm test                # vše, headless (desktop + mobil Pixel 7)
npm run test:ui         # interaktivní UI – doporučuji na první seznámení
npm run test:mobile     # jen mobilní viewport
npm run report          # HTML report po běhu
FF_URL=http://localhost:5000 npm test   # proti lokálnímu firebase serve
```

## Co testy hlídají
| Soubor | Hlídá |
|---|---|
| 01-landing | Landing se načte, bez JS chyb, odkaz do app |
| 02-app-shell | App bez chyb, login viditelný, manifest validní (PWABuilder) |
| 03-version-consistency | **title = sidebar = sw.js verze** (chyba v7.55!) + všechny hashované JS existují |
| 04-product-db | Integrita product-groups.json na produkci |

## Další krok (až bude čas)
Přihlášené testy: Firebase Auth emulator + seed testovacích dat
(`firebase emulators:start`), pak lze testovat transakce, Runway, COICOP UI.
