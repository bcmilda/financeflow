// Produktová DB (S12.1) – integrita dat na produkci
const { test, expect } = require('@playwright/test');

test('product-groups.json je validní a kompletní', async ({ request }) => {
  const res = await request.get('/data/product-groups.json');
  expect(res.ok(), 'data/product-groups.json nenasazen?').toBeTruthy();
  const db = await res.json();
  expect(Object.keys(db.groups).length).toBeGreaterThanOrEqual(400);
  expect(db.reps.length).toBe(427);
  expect(Object.keys(db.keywords).length).toBeGreaterThan(1000);
  // každý keyword míří na existující skupinu
  for (const [kw, code] of Object.entries(db.keywords)) {
    expect(db.groups[code], `keyword "${kw}" → neexistující kód ${code}`).toBeTruthy();
  }
});
