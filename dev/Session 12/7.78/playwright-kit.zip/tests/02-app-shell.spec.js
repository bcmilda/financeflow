// App shell (financeflow.cz/app) – nepřihlášený stav
const { test, expect } = require('@playwright/test');

test.describe('App shell (bez přihlášení)', () => {
  test('app.html se načte bez JS chyb', async ({ page }) => {
    const errors = [];
    page.on('pageerror', e => errors.push(e.message));
    await page.goto('/app');
    await page.waitForTimeout(2500); // Firebase init
    expect(errors, 'JS chyby: ' + errors.join('; ')).toHaveLength(0);
  });

  test('zobrazí Google přihlášení, NE data aplikace', async ({ page }) => {
    await page.goto('/app');
    // tlačítko přihlášení viditelné
    await expect(page.getByText(/Google|Přihlásit/i).first()).toBeVisible({ timeout: 10000 });
  });

  test('manifest.json je validní a absolutní', async ({ request }) => {
    const res = await request.get('/manifest.json');
    expect(res.ok()).toBeTruthy();
    const m = await res.json();
    expect(m.start_url).toContain('financeflow.cz');   // PWABuilder fix (S12)
    expect(m.icons?.length).toBeGreaterThan(0);
  });
});
