// Landing page (financeflow.cz) – smoke testy
const { test, expect } = require('@playwright/test');

test.describe('Landing page', () => {
  test('načte se a má správný title', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/FinanceFlow/);
  });

  test('neobsahuje JS chyby v konzoli', async ({ page }) => {
    const errors = [];
    page.on('pageerror', e => errors.push(e.message));
    await page.goto('/');
    await page.waitForLoadState('networkidle');
    expect(errors, 'JS chyby na landing page: ' + errors.join('; ')).toHaveLength(0);
  });

  test('obsahuje odkaz do aplikace', async ({ page }) => {
    await page.goto('/');
    const appLink = page.locator('a[href*="app"]').first();
    await expect(appLink).toBeVisible();
  });
});
