// Hlídač konzistence verzí – přesně ta chyba, co strašila v náhledech (v7.55)!
// Selže, když <title>, sidebar nebo sw.js CACHE_NAME nemají STEJNOU verzi.
const { test, expect } = require('@playwright/test');

const VER_RE = /v?(7\.\d+)/;

test('verze v <title>, sidebaru a sw.js jsou identické', async ({ page, request }) => {
  await page.goto('/app');
  const title = await page.title();                       // "FinanceFlow v7.78"
  const titleVer = title.match(VER_RE)?.[1];
  expect(titleVer, 'Title neobsahuje verzi: ' + title).toBeTruthy();

  const html = await (await request.get('/app')).text();
  const sidebarVer = html.match(/<small>v(7\.\d+)/)?.[1];
  expect(sidebarVer, 'Sidebar logo bez verze').toBeTruthy();

  const sw = await (await request.get('/sw.js')).text();
  const swVer = sw.match(/ff-shell-v(7\.\d+)/)?.[1];
  expect(swVer, 'sw.js bez CACHE_NAME verze').toBeTruthy();

  expect(sidebarVer, `Sidebar (${sidebarVer}) ≠ title (${titleVer})`).toBe(titleVer);
  expect(swVer, `sw.js (${swVer}) ≠ title (${titleVer})`).toBe(titleVer);
});

test('všechny verzované JS soubory z app.html existují (hash cache-busting)', async ({ request }) => {
  const html = await (await request.get('/app')).text();
  const refs = [...html.matchAll(/src="(js\/[\w-]+\.js\?v=[a-f0-9]{16})"/g)].map(m => m[1]);
  expect(refs.length).toBeGreaterThan(10);
  for (const ref of refs) {
    const res = await request.get('/' + ref);
    expect(res.ok(), `Soubor nedostupný: ${ref}`).toBeTruthy();
  }
});
